//
//  Booking.swift
//  Airline
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Booking : Flight{
    private var bookingID : Int
    private var bookingDate : Date
    private var bookingStatus : bookingStatusList?
    private var selectedflight : [flightdetail]
    private var dataHelper = DataHelper()
    
    var BookingID : Int{
        get { return self.bookingID }
        set{ self.bookingID = newValue}
    }
    var BookingDate : Date{
        get { return self.bookingDate }
        set{ self.bookingDate = newValue}
    }
    var BookingStatus : bookingStatusList?{
        get { return self.bookingStatus ?? bookingStatusList.nobooking }
        set{ self.bookingStatus = newValue}
    }
    
    //computed property
    var flightCost: Double?{
        get{
            var Cost = 0.0
            if !self.selectedflight.isEmpty{
                for (_, prod, qty) in self.selectedflight{
                   Cost  += prod.UnitPrice! * (Double)(qty)
                }
            }
            return Cost
        }
    }
    
    override init(){
        self.bookingID = 0
        self.bookingDate = DateFormatter().date(from: "")!
        self.bookingStatus = bookingStatusList.nobooking
        self.selectedflight = []
        super.init()
    }
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n bookingID : \(self.BookingID)"
        returnData += "\n booking Date : \(self.BookingDate )"
        //        returnData += super.displayData()
        returnData += "\n PlaneList : "
        if !self.selectedflight.isEmpty{
            for (_, flight) in self.selectedflight{
                returnData += "\n \tflight : \(flight.displayData())"
              
            }
        }else{
            returnData += "\n No selected flight "
        }
        returnData += "\n Booking Status : \(self.BookingStatus ?? bookingStatusList.nobooking)"
        returnData += "\n flight Cost : \(self.flightCost  ?? 0.0)"
        
        return returnData
    }
    
    func addOrder(){
        dataHelper.displayFlight()
        print("Please enter flight ID to select any flight from the list : ")
        let selectedflightID : Int = (Int)(readLine()!)!
        
        if let selectedflight = dataHelper.searchflight(flightId: selectedflightID){
            self.bookingID = selectedflightID
            self.BookingDate = Date()
            
            
            
            self.selectedflight += [(flightID: selectedflightID, flight: SelectedFlight)]
            self.BookingStatus = BookingStatusList.Placed
            
        }else{
            print("Sorry...The flight you entered is unavailable")
        }
    }
    
    func cancelBooking(){
        if !selectedflight.isEmpty {
            print("Review your booking \n \(self.displayData())")
            
            print("Please enter flight ID to remove from the booking : ")
            let selectedFlightID : Int = (Int)(readLine()!)!
            var flightIndex = -1
            
            for (index, flight) in self.selectedflight.enumerated(){
                if (flight.flightID == selectedFlightID){
              flightindex = index
                }
            }
            
            if flightIndex != -1{
                self.bookingFlights.remove(at: productIndex)
                print("The flight is removed from your booking")
            }
        }else{
            print("You have no flight in your booking")
        }
    }
}

    
}
