//
//  DataHelper.swift
//  Airline
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var List = [Int : Flight]()
    init(){
        self.loadFlights()
    }
    
    func loadFlights(){
        let Vistara = Flight(flightID : 5511, flightFrom : "Canada", flightTo: "India",flightAirplaneID : 3310 ,flightPilotId : 2211, airLineID : 11,type: PlaneType.Boeing)
        List[Vistara.flightID!] = Vistara
        
        let AirCanada = Flight(flightID : 1102, flightFrom : "Canada", flightTo: "America",flightDate: Date,flightAirplaneID : 1118 ,flightPilotId : 2115, airLineID : 12,type: PlaneType.Charter)
        List[AirCanada.flightID!] = AirCanada
        
        
        let JetAirways = Flight(flightID : 234, flightFrom : "India", flightTo: "Canada",flightDate: Date,flightAirplaneID : 2717 ,flightPilotId : 1311, airLineID : 13,PlaneType.Boeing)
        List[JetAirways.flightID!] = JetAirways
        
        
        let AirEmirates = Flight(flightID : 4421, flightFrom : "Dubai", flightTo: "India",flightDate: Date,flightAirplaneID : 4321 ,flightPilotId : 4415, airLineID : 14,PlaneType.Charter)
        List[AirEmirates.flightID!] = AirEmirates
        
        let AirFrane = Flight(flightID: 2211, flightFrom: "America", flightTo: "Canada,  flightAirplaneID: 1122, flightPilotId: 2345, airLineID: 15, type: PlaneType.Bombart)
        
        let TurkishAirlines = Flight(airportName : "Turkey International Airport", airportID : 771, country : "Turkey", flightID : 7172, flightFrom : "Turkey", flightTo: "China",flightDate: Date,flightAirplaneID : 7766 ,flightPilotId : 7290, airLineID : 16,PlaneType.Bombart)
        List[TurkishAirlines.flightID!] = TurkishAirlines
        
        
        let AirChina = Flight(airportName : "Sanghai Airport", airportID : 881, country : "China", flightID : 8088, flightFrom : "China", flightTo: "Germany",flightDate: Date,flightAirplaneID : 8282 ,flightPilotId : 8111, airLineID : 17,PlaneType.Bombart)
        List[AirChina.flightID!] = AirChina
    }
    
    func displayProducts(){
        //closure
        for (_,prod) in PlaneList.sorted(by: {$0.key < $1.key}){
            print("\(prod.displayData())")
        }
    }
}

