//
//  DataHelper.swift
//  Airline
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var PlaneList = [Int : Flight]()
    init(){
        self.loadFlights()
    }
    
    func loadFlights(){
        let AirCanada = Flight(flightID : 5555, flightFrom : "Canada", flightTo: "India", flightAirplaneID : 1234 ,flightPilotId : 2222, airLineID : 01,type: PlaneTypeCategory.Boeing)
        PlaneList[AirCanada.flightID!] = AirCanada
        
        let AirChina = Flight(flightID : 1111, flightFrom : "China", flightTo: "Dubai", flightAirplaneID : 1118 ,flightPilotId : 3456, airLineID : 02,type: PlaneTypeCategory.Charter)
        PlaneList[AirChina.flightID!] = AirChina
        
        
        let JetAirways = Flight(flightID : 5678, flightFrom : "India", flightTo: "Canada", flightAirplaneID : 6781 , flightPilotId : 1331, airLineID : 03, type: PlaneTypeCategory.Boeing)
        PlaneList[JetAirways.flightID!] = JetAirways
        
        
        let AirInuit = Flight(flightID : 4444, flightFrom : "Canada", flightTo: "America", flightAirplaneID : 2678 , flightPilotId : 1111, airLineID : 04,type  : PlaneTypeCategory.Charter)
        PlaneList[AirInuit.flightID!] = AirInuit
        
        let AirFrane = Flight(flightID: 9876, flightFrom: "America", flightTo: "Canada",  flightAirplaneID: 4562, flightPilotId: 2345, airLineID: 05, type: PlaneTypeCategory.Bombart)
         PlaneList[AirFrane.flightID!] = AirFrane
        
        let AirGeorgian = Flight(flightID : 4567, flightFrom : "Canada", flightTo: "New Zealand", flightAirplaneID : 7654 ,flightPilotId : 1290, airLineID : 06,type: PlaneTypeCategory.Bombart)
        PlaneList[AirGeorgian.flightID!] = AirGeorgian
        
        
        let AirCreebec = Flight(flightID : 8652, flightFrom : "Canada", flightTo: "Germany",flightAirplaneID : 9065 ,flightPilotId : 2789, airLineID : 07, type : PlaneTypeCategory.Bombart)
        PlaneList[AirCreebec.flightID!] = AirCreebec
    }
    
    func displayFlight(){
        //closure
        for (_,flights) in PlaneList.sorted(by: {$0.key < $1.key}){
            print("\(flights.displayData())")
        }
    }
    func searchflight(flightId : Int) -> Flight?{
        if PlaneList[flightId]  != nil{
            return PlaneList[flightId]! as Flight
        }
        else{
        print("Sorry...the flight for destination you entered is not available ")
            return nil
    }
        func  selectflight() -> Flight {
            var flights = (Int)(readLine()!)
            return (PlaneList[flights!] ?? nil)!
        }
}
}
