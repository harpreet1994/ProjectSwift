//
//  PlaneType.swift
//  Airline
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Planetype{
    var plane_type_id : String?
    var total_seats : Int?
    var seat_map : String?
    init(){
        
    }
}
