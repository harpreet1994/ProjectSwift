//
//  PlaneType.swift
//  Airline
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Plane{
    var planeID : Int?
    var TotalSeat : Int?
    
}
