//
//  main.swift
//  Airline
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

/*let dateCurrent = Date()
print("Date 1 : \(dateCurrent)")

let dateString = "23/04/2018"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "MM/dd/yyyy"
let dateFromString = dateFormatter.date(from: dateString)
print("Date 2 : \(dateFromString!)") */
var rimpal = Passenger()
print(rimpal.displayData())

//var harpreet = Passenger(passengerID : 111, passportNo : "abc", passengerName : "harpreet", mobile : "def" , email : "hbajwa@gmail.com", address :  "upperhumber dr")
//print("\(harpreet.displayData())")


var harpreet = Passenger(passengerID: 101, passportNo: "K5390380", passengerName: "GS", mobile: "8042080420", email: "KuchV", address: "Pta ni", birthDate: Date.init(timeIntervalSince1970: 1))
print(harpreet.displayData())


rimpal.PassengerID = 111
rimpal.PassportNo = "mn123"
rimpal.PassengerName = "Rimpal"
rimpal.Mobile = "1234"
rimpal.Email = "rimpal@gmail.com"
rimpal.Address = "Brampton"
rimpal.BirthDate = nil

var dataHelper = DataHelper()
dataHelper.displayFlights()
