//
//  main.swift
//  Airline
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//
//var AvailableFlights = [Any]()
//
//var req = Flight()
//
//
//var f1 = DataHelper()
//var AvailableFlights = f1.searchflight()!
//print("Available flights for this Destination")
//for all in AvailableFlights {
//    print(all.displayData())
//}
//print("select flight by using Flight ID (Enter Flight ID)")
//print(f1.selectflight().displayData())
//
//print(" do you want to book this flight \n 1. Yes    2. No")
//var choice = (Int)(readLine()!)
//switch choice{
//case 1:
//    print("Please Enter Following Details")
//
//    var p = Passenger()
//   print("Enter ID")
//    p.passengerID = (Int) readline()!
//    print("Enter Name")
//    p.passengerName = readLine()!
//    print("Enter Email")
//    p.email = readLine()!
//    print("Enter Mobile Number")
//    p.mobile = readLine()!
//    print("Enter your Passport Number")
//    p.PassportNo = readLine()!
//    print("Enter your Date of Birth with format(MM/dd/yyyy)")
//    p.birthDate = readLine()!
//    p.birthDate
//    p.displayData()
//    print("Confirm entered details")
//
//    var res = Reservation()
//
//
//    (resID : Int, resPassengerID : Int,resFlightID : Int, resDescription : String, resMealType : String,resDate : Date,resSeatNo : String, resStatus : Bool)
//case 2:
//    print("thanks..")
//
//default:
//    print("wrong choice")
//}
//
//default:
//print("Wrong choice. Select again")
//
//} }while (flag != 1)
////var fl = Flight()
////print(fl.displayData())
//
var select = 1
let dataHelper = DataHelper()
var book = Booking()

while select != 6{
    print("\n----What would you like to do today !----")
    print("\t 1 : Plane List ")
    print("\t 2 : Add flight ")
    print("\t 3 : Show flight")
    print("\t 4 : Update flight ")
    print("\t 5 : Cancel flight ")
    print("\t 6 : Exit ")
    print("-----------------------------------------")
    print("Enter you selection please : ")
    select = (Int)(readLine()!)!
    
    switch select{
    case 1:
        dataHelper.displayFlight()
    case 2:
        book.addBooking()
    case 3:
        print(book.displayData())
           case 4:
        book.updateBooking()
    case 5:
        book.cancelBooking()
    case 6:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}





//var dataHelper = DataHelper()
//dataHelper.displayFlight()
