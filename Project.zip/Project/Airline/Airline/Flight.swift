//
//  Flight.swift
//  Airline
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight {
    var flightID : Int?
    var flightFrom : String?
    var flightTo : String?
    var flightDate = Date()
    var flightAirplaneID : Int?
    var flightPilotId : Int?
    var airLineID : Int?
    var type : PlaneType?
    
    
    
       init(){
        //super.init()
        self.flightID = 0
        self.flightFrom  = ""
        self.flightTo = ""
        self.flightDate = Date()
        self.flightAirplaneID = 0
        self.flightPilotId  = 0
        self.airLineID = 0
        self.type = PlaneType.Charter
        
    }
    
    
    
    //parameterized initializer
    init(flightID : Int, flightFrom : String, flightTo: String,flightAirplaneID : Int,flightPilotId : Int, airLineID : Int, type : PlaneType){
        self.flightID = flightID
        self.flightFrom  = flightFrom
        self.flightTo = flightTo
        self.flightAirplaneID = flightAirplaneID
        self.airLineID = airLineID
        self.type = type
       /* self.flightDate = set{
            let dateCurrent = Date()
            print("Date 1 : \(dateCurrent)")
            
            let dateString = "23/04/2018"
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            let dateFromString = dateFormatter.date(from: dateString)
            print("Date 2 : \(dateFromString!)")
            //self.flightDate = newValue */
        }
    
    
    //stored property
    var FlightID : Int?{
        get { return self.flightID}
        set { self.flightID = newValue}
}
    var FlightFrom : String?{
        get{return self.flightFrom}
        set{self.flightFrom = newValue}}
    var FlightTo : String?{
        get{return self.flightTo}
        set{self.flightTo = newValue}}
    var FlightDate : String?{
        //get{return self.flightDate}
       // set{
          //  let dateCurrent = Date()
           // print("Date 1 : \(dateCurrent)")
            
           // let dateString = "23/04/2018"
           // let dateFormatter = DateFormatter()
           // dateFormatter.dateFormat = "MM/dd/yyyy"
            //let dateFromString = dateFormatter.date(from: dateString)
            //print("Date 2 : \(dateFromString!)")
            //self.flightDate = newValue
        
    
    var FlightAirplaneID : Int?{
        get{return self.flightAirplaneID}
        set{self.flightAirplaneID = newValue}
    }
    var FlightPilotId  : Int?{
        get{return self.flightPilotId }
        set{self.flightPilotId  = newValue}
    }
    var AirLineID : Int?{
        get{return self.airLineID}
        set{self.airLineID  = newValue}
    }
    var Types : PlaneType? {
        get{ return self.type }
        set{ self.type = newValue }
    }
    
    
    func displayData() -> String{
        var returnData = ""
        
        if self.flightID != nil {
            returnData += "\n Flight ID : \(self.flightID ?? 0)"
        }
        
        if self.flightFrom != nil {
            returnData += "\n Flight Starting Point : \(self.flightFrom ?? "Unknown")"
        }
        if self.flightTo != nil {
            returnData += "\n Flight Destination : \(self.flightTo ?? "Unknown")"
        }
       // returnData += "\n Flight date : \(self.flightDate ?? Date)"
        
        if self.flightAirplaneID != nil {
            returnData += "\n Plane ID Info : \(self.flightAirplaneID ?? 0)"
        }
        if self.flightPilotId != nil {
            returnData += "\n  Pilot ID Info : \(self.flightPilotId ?? 0)"
        }
        
        if self.airLineID != nil {
            returnData += "\n Airline ID Info : \(self.airLineID ?? 0)"
        }
        if self.type != nil {
            
            returnData += "\n type : \(self.type ?? PlaneType.Charter)"
        }
        return returnData
    }
    
    func bookTicket(){
       
        print("Enter Flight ID : ")
        self.flightID = (Int)(readLine()!)
        print("Enter Flight Starting Point : ")
        self.flightFrom = readLine()!
        print("Enter Flight Destination : ")
        flightTo = readLine()!
        //print("Enter Flight Date : ")
       // self.flightDate = readLine()!
        print("Enter Flight pilot ID : ")
        self.flightPilotId = (Int)(readLine()!)
        print("Enter Airline ID : ")
        self.airLineID = (Int)(readLine()!)
        print("Enter AirplaneID Info : ")
        self.flightAirplaneID = (Int)(readLine()!)
        
        print("Please choose from the following Plane Types")
        for category in PlaneType.allCases{
            print("Enter \(category.rawValue) for \(category)")
        }
        let choice = (Int)(readLine()!) ?? 1
        self.type = PlaneType(rawValue: choice)
        
        
        
    }

}
}
