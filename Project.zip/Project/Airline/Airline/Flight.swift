//
//  Flight.swift
//  Airline
//
//  Created by MacStudent on 2018-07-30.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight : IDisplay {

    var flightID : Int
    var flightFrom : String
    var flightTo : String
    var flightDate : String
    var flightAirplaneID : Int
    var flightPilotId : Int
    var airLineID : Int
    var type : PlaneTypeCategory
  
    
    
    init(){
        
        self.flightID = 0
        self.flightFrom  = ""
        self.flightTo = ""
        self.flightDate = ""
        self.flightAirplaneID = 0
        self.flightPilotId  = 0
        self.airLineID = 0
        self.type = PlaneTypeCategory.None
        
    }
    
    
    
    //parameterized initializer
    init(flightID : Int, flightFrom : String, flightTo: String,flightDate : String ,flightAirplaneID : Int,flightPilotId : Int, airLineID : Int, type : PlaneTypeCategory){
        self.flightID = flightID
        self.flightFrom  = flightFrom
        self.flightTo = flightTo
        self.flightDate = flightDate
        self.flightAirplaneID = flightAirplaneID
        self.flightPilotId = flightPilotId
        self.airLineID = airLineID
        self.type = type
       
    }
    
    var FlightID : Int
    {
        get { return self.flightID}
        set { self.flightID = newValue}
    }
    var FlightFrom : String
    {
        get{return self.flightFrom}
        set{self.flightFrom = newValue}}
    var FlightTo : String
    {
        get{return self.flightTo}
        set{self.flightTo = newValue}}
    
    var FlightDate : String
    {
        get{return self.flightDate}
        set{self.flightDate = newValue}
    }
    var FlightAirplaneID : Int
    {
        get{return self.flightAirplaneID}
        set{self.flightAirplaneID = newValue}
    }
    var FlightPilotId  : Int
    {
        get{return self.flightPilotId }
        set{self.flightPilotId  = newValue}
    }
    var AirLineID : Int
    {
        get{return self.airLineID}
        set{self.airLineID  = newValue}
        
    }
   
    
    var Types : PlaneTypeCategory {
        get{ return self.type }
        set{ self.type = newValue }
    }
    
    
    func displayData() -> String {
        var returnData = ""
        
        if self.flightID != nil {
            returnData += "\n Flight ID : \(self.flightID)"
        }
        
        if self.flightFrom != nil {
            returnData += "\n Flight Starting Point : \(self.flightFrom)"
        }
        if self.flightTo != nil {
            returnData += "\n Flight Destination : \(self.flightTo)"
        }
        if self.flightDate != nil {
            returnData += "\n Plane Date Info : \(self.flightDate)"
        }
        if self.flightAirplaneID != nil {
            returnData += "\n Plane ID Info : \(self.flightAirplaneID)"
        }
        if self.flightPilotId != nil {
            returnData += "\n  Pilot ID Info : \(self.flightPilotId)"
        }
        
        if self.airLineID != nil {
            returnData += "\n Airline ID Info : \(self.airLineID)"
        }
        if self.type != nil {
            
            returnData += "\n type : \(self.type ?? PlaneTypeCategory.None)"
        }
        return returnData
    }
    
    
   
    
    //stored property
    
    
    func bookTicket(){
        
        print("Enter Flight ID : ")
        self.flightID = (Int)(readLine()!)!
        print("Enter Starting Point of flight : ")
        self.flightFrom = readLine()!
        print("Enter Destination of flight: ")
        flightTo = readLine()!
        print("Enter Flight Date : ")
        self.flightDate = readLine()!
        print("Enter Flight pilot ID : ")
        self.flightPilotId = (Int)(readLine()!)!
        print("Enter Airline ID : ")
        self.airLineID = (Int)(readLine()!)!
        print("Enter AirplaneID Info : ")
        self.flightAirplaneID = (Int)(readLine()!)!
        
        print(" Choose from the following Plane Types")
        for category in PlaneTypeCategory.allCases{
            print("Enter \(category.rawValue) for \(category)")
        }
        let choice = (Int)(readLine()!) ?? 1
        self.type = PlaneTypeCategory(rawValue: choice)!
      
        
    }
    
}
