//
//  Reservation.swift
//  Airline
//
//  Created by MacStudent on 2018-07-30.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation {
    var resID : Int?
    var resPassengerID : Int?
    var resFlightID : Int?
    var resDescription : String?
    var mealType : MealtypeList?
    var resDate : Date?
    var resSeatNo : String?
    var resStatus : Bool?
    
    init(){
        self.resID = 0
        self.resPassengerID = 0
        self.resFlightID = 0
        self.resDescription = "Unknown"
        self.mealType = MealtypeList.None
        self.resDate = Date()
        self.resSeatNo = "Unknown"
        self.resStatus = false
        
    }
    init(resID : Int,resPassengerID : Int,resFlightID : Int, resDescription : String,mealType : MealtypeList,resDate : Date,resSeatNo : String, resStatus : Bool
        ){
        self.resID = resID
        self.resPassengerID = resPassengerID
        self.resFlightID = resFlightID
        self.resDescription = resDescription
        self.mealType = mealType
        self.resSeatNo = resSeatNo
        self.resStatus = resStatus
    }
    
    func display() {
        print(self.resID ?? 0  )
        print(self.resPassengerID ?? 0)
        print(self.resFlightID ?? 0)
        print(self.resDescription ?? "")
        print(self.mealType ?? MealtypeList.None )
        print(self.resSeatNo ?? "")
        print(self.resStatus ?? false )
    }
    
}
