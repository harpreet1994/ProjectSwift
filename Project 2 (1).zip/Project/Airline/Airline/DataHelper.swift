//
//  DataHelper.swift
//  Airline
//
//  Created by MacStudent on 2018-07-30.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var FlightList = [Int : Flight]()
    var AirlineList = [Int : Airline]()
    
    
    init(){
        self.loadFlights()
        self.loadAirline()
    }
    func loadAirline(){
        AirlineList = [:]
        
        let p1 = Airline(airlineID: 11, description: "World's largest flight", airlineType: "Business Class", category:AirlineCategory.American)
        AirlineList[p1.airlineID!] = p1
        
        let p2 = Airline(airlineID: 12, description: "it covers more international destination", airlineType: "Career and business", category: AirlineCategory.United)
            AirlineList[p2.airlineID!] = p2
        
        let p3 = Airline(airlineID: 13, description: "one of the oldest airline", airlineType: "low cost ", category: AirlineCategory.Alaska)
        AirlineList[p3.airlineID!] = p3
        
        let p4 = Airline(airlineID: 14, description: "world's largest airline", airlineType: "Business class", category: AirlineCategory.Delta)
        AirlineList[p4.airlineID!] = p4
    }
    func displayAirline(){
        print(" Enter Airline Details")
        Util.drawLine()
        print("\t ID \t\t Description \t\t\t\t  Type \t\t Alirline")
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.airlineID!) ------ \(value.description!) ------ \(value.airlineType!) ------ \(value.category!)")
        }
        Util.drawLine()
    }
    
       /* func displayFlight(){
        print(" Flight Details")
        Util.drawLine()
        print("\t flightID \t\t flightFrom \t\t\t\t flightTo \t\t flightAirplaneID \t\t flightPilotID \t\t AirlineID \t\t Category \t\tflightClass ")
        
        for (_, flight) in FlightList.sorted(by: {$0.key < $1.key}){
            Util.drawLine()
            print("\(flight.displayData())")
        }
        Util.drawLine()
    }
    
    func searchflight(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry...the flight for destination you entered is not available ")
            return nil
        }
    }*/
    
    func loadFlights(){
        FlightList = [:]
        let AirCanada = Flight(flightID: 3333, flightFrom: "Canada", flightTo: "Europe", flightDate: "10/08/2018" , flightAirplaneID: 3452, flightPilotId: 9234, airLineID: 01,price: 34.78,type: PlaneTypeCategory.Boeing, flightClass:FlightCategory.Economy)
        FlightList[AirCanada.flightID] = AirCanada
        
        let AirChina = Flight(flightID : 1111, flightFrom : "China", flightTo: "Australia",flightDate: "11/09/2018",flightAirplaneID : 1118 ,flightPilotId : 3456, airLineID : 02,price: 45.78,type: PlaneTypeCategory.Bombart, flightClass :FlightCategory.Business)
        FlightList[AirChina.flightID] = AirChina
        
        
        let JetAirways =  Flight(flightID : 5678, flightFrom : "India", flightTo: "Canada",flightDate: "01/11/2018",flightAirplaneID : 6781 , flightPilotId : 1331, airLineID : 03,price: 23.8, type: PlaneTypeCategory.Charter, flightClass: FlightCategory.FirstClass)
        FlightList[JetAirways.flightID] = JetAirways
        
        
        let AirInuit =  Flight(flightID : 4444, flightFrom : "Canada", flightTo: "America",flightDate: "29/01/2019",flightAirplaneID : 2678 , flightPilotId : 1111, airLineID : 04,price: 12.67,type  : PlaneTypeCategory.Bombart,flightClass: FlightCategory.none)
        FlightList[AirInuit.flightID] = AirInuit
        
        let AirFrane =  Flight(flightID: 9876, flightFrom: "America", flightTo: "Canada",flightDate: "10/09/2018",flightAirplaneID: 4562, flightPilotId: 2345, airLineID: 05,price: 67.21, type: PlaneTypeCategory.Boeing, flightClass: FlightCategory.Economy)
        FlightList[AirFrane.flightID] = AirFrane
        
        let AirGeorgian = Flight(flightID : 4567, flightFrom : "Canada", flightTo: "New Zealand",flightDate: "01/08/2018",flightAirplaneID : 7654 ,flightPilotId : 1290, airLineID : 06,price: 37.91, type: PlaneTypeCategory.Charter,flightClass: FlightCategory.Business)
        FlightList[AirGeorgian.flightID] = AirGeorgian
        
        
        let AirCreebec =  Flight(flightID : 8652, flightFrom : "Canada", flightTo: "Germany", flightDate: "11/10/2018", flightAirplaneID : 9065 ,flightPilotId : 2789, airLineID : 07,price: 27.71, type : PlaneTypeCategory.Boeing,flightClass: FlightCategory.FirstClass)
        FlightList[AirCreebec.flightID] = AirCreebec
    }
    
    func displayFlight(){
        print(" Flight Details")
        Util.drawLine()
        print("\t flightID \t\t flightFrom \t\t\t\t flightTo \t\t flightAirplaneID \t\t flightPilotID \t\t AirlineID \t\t Category \t\tflightClass ")
        
        for (_, flight) in FlightList.sorted(by: {$0.key < $1.key}){
            Util.drawLine()
            print("\(flight.displayData())")
        }
        Util.drawLine()
    }
    
    func searchflight(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry...the flight for destination you entered is not available ")
            return nil
        }
    }
    
    
    func  selectedflight() -> Flight {
        let flights = (Int)(readLine()!)
        return (FlightList[flights!] ?? nil)!
    }
}



