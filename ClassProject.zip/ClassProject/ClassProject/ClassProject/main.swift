//
//  main.swift
//  ClassProject
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


print("Hello, World!")

var rimpal = Passenger()
print(rimpal.displayData())

//var harpreet = Passenger(passengerID : 111, passportNo : "abc", passengerName : "harpreet", mobile : "def" , email : "hbajwa@gmail.com", address :  "upperhumber dr")
//print("\(harpreet.displayData())")


var harpreet = Passenger(passengerID: 101, passportNo: "K5390380", passengerName: "GS", mobile: "8042080420", email: "KuchV", address: "Pta ni", birthDate: Date.init(timeIntervalSince1970: 1))
print(harpreet.displayData())


rimpal.PassengerID = 111
rimpal.PassportNo = "mn123"
rimpal.PassengerName = "Rimpal"
rimpal.Mobile = "1234"
rimpal.Email = "rimpal@gmail.com"
rimpal.Address = "Brampton"
rimpal.BirthDate = nil

var sarb =  Employee()
sarb.newEmployee()
print(sarb.displayData())
