//
//  Protocol.swift
//  ClassProject
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//protocol or interface

protocol IDisplay{
    func displayData() -> String
    
}
