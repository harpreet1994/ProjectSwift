//
//  Employee.swift
//  ClassProject
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Employee : IDisplay{
    
    var empID : Int?
    var empName : String?
    var empEmail : String?
    var mobile : String?
    var address : String?
    var designation : String?
    var sin : String?
    
    var EmpID : Int?{
    get{ return self.empID}
    set{ self.empID = newValue}
    }
    var EmpName : String?{
        get{ return self.empName}
        set{self.empName = newValue}
    }
    var EmpEmail : String?{
        get{return self.EmpEmail}
        set{self.empEmail = newValue}
    }
    var Mobile : String?{
        get{return self.Mobile}
        set{self.mobile = newValue}
    }
    var Address : String?{
        get{return self.address}
        set{self.address = newValue}
    }
    var Designation : String?{
        get{return self.designation}
        set{self.designation = newValue}
    }
    var Sin : String?{
        get{return self.sin}
        set{self.sin = newValue}
    }
    init(){
        self.empID = 0
        self.empName = ""
        self.empEmail = ""
        self.mobile = ""
        self.address = ""
        self.designation = ""
        self.sin = ""
    }
    init(empID : Int, empName: String, empEmail: String, mobile: String, address: String, designation : String, sin: String){
        self.empID = empID
        self.empName = empName
        self.empEmail = empEmail
        self.address = address
        self.designation = designation
        self.sin = sin
    }
    func displayData() -> String {
     var returnData = ""
        
        returnData += "\n emp ID : \(self.empID ?? 0)"
        returnData += "\n emp Name : \(self.empName ?? "")"
        returnData += "\n emp Email :\(self.empEmail ?? "")"
        returnData += "\n emp Mobile :\(self.mobile ?? "")"
        returnData += "\n Address : \(self.address ?? "")"
        returnData += "\n Designation :\(self.designation ?? "")"
        returnData += "\n SIN : \(self.sin ?? "") "
        return returnData
    }
        
    func newEmployee(){
        print("Enter Employee ID : ")
        self.empID = (Int)(readLine()!)
        print(" Enter Employee Name : ")
        self.empName = readLine()
        print(" Enter Employee Email : ")
        self.empEmail = readLine()
        print(" Enter Employee Mobile : ")
        self.mobile = readLine()
        print(" Enter Employee Address : ")
        self.address = readLine()
        print(" Enter Employee Designation : ")
        self.designation = readLine()
        print(" Enter Employee Sin : ")
        self.sin = readLine()
        
    }
    
    
}
