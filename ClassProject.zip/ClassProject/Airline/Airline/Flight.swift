//
//  Flight.swift
//  Airline
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight : IDisplay {
    func displayData() -> String {
        
    
    
    
    
        var flightID : String?
        var flightFrom : String?
        var flightTo : String?
        var schduleDate : Date?
        var flightAirlineID : Int?
        var flightAirPlane : String?
        var pilotId : String?
        
        
        var FlightID : String?
        get{return self.flightID}
        set{self.flightID = newValue}
    
}

var FlightFrom : String?
get{return self.flightFrom}
set{self.flightFrom = newValue}
}

var FlightTo : String?
get{return self.flightTo}
set{self.flightTo = newValue}
}

var SchduleDate : String?
get{return self.schduleDate}
set{self.schduleDate = newValue}
}

var


func displayData() -> String {
    
}

