//
//  Protocol.swift
//  Airline
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//protocol or interface

protocol IDisplay{
    func displayData() -> String
    
}
